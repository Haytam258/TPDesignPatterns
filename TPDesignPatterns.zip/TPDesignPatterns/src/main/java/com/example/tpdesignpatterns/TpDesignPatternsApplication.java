package com.example.tpdesignpatterns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpDesignPatternsApplication {

    public static void main(String[] args) {
        SpringApplication.run(TpDesignPatternsApplication.class, args);
    }

}
